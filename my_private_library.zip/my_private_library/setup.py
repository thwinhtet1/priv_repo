from setuptools import setup, find_packages

setup(
    name='my_private_library',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[],
    author='Your Name',
    author_email='your.email@example.com',
    description='A private Python library for internal use',
    url='https://your-private-repo.url',
)
